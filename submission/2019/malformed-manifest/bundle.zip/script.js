console.log("this script is very loaded");
