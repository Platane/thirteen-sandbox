console.log("this script is very loaded");

throw new Error("something bad happend");
