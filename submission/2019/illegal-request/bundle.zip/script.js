console.log("this script is very loaded");

fetch("http://worldclockapi.com/api/json/est/now")
  .then(res => res.text())
  .then(text => {
    document.getElementById("time").innerHTML = text;
  });
