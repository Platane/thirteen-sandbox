console.log("this script is very loaded");

fetch(
  "https://gist.githubusercontent.com/Platane/20026468d92c5d63a6fe71265d1fda08/raw/7d6271916d7ab9964728d2e75086f7d3c4848a58/insaneJMad"
)
  .then(res => res.text())
  .then(text => {
    document.getElementById("time").innerHTML = text;
  });
